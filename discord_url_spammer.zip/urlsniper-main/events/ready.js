const Discord = require("discord.js");

module.exports = client => {
  client.user.setStatus("online");

  //Botun Durumu
  //online=Çevrimiçi
  //idle=Boşta
  //dnd=Rahatsız Etmeyin
  //invisible=Görünmez
};
